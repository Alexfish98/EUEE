package com.example.database

import com.example.core.model.AlarmCategory
import com.example.core.model.Difficulty
import com.example.core.model.QuestionType
import com.example.core.model.TaskPriority
import java.time.LocalDate

object SeedDataProvider {

    suspend fun seedIfEmpty(db: EueeDatabase) {
        val curriculum = db.curriculumDao()
        if (curriculum.getAllSubjects().isNotEmpty()) return

        // 1. Question Bank
        val builtInBankId = curriculum.insertQuestionBank(
            QuestionBankEntity(
                name = "EUEE Core Curriculum Bank",
                description = "Ethiopian University Entrance Examination (Grades 9-12) offline foundation set",
                sourceType = "BUILT_IN"
            )
        )

        // 2. Grades 9..12
        val gradeIds = mutableMapOf<Int, Long>()
        for (level in 9..12) {
            gradeIds[level] = curriculum.insertGrade(GradeEntity(level = level, label = "Grade $level"))
        }

        // 3. All 6 EUEE Subjects
        val mathId = curriculum.insertSubject(SubjectEntity(name = "Mathematics", category = "Natural Science", colorHex = 0xFF2563EB, iconName = "Calculate"))
        val physicsId = curriculum.insertSubject(SubjectEntity(name = "Physics", category = "Natural Science", colorHex = 0xFF7C3AED, iconName = "Science"))
        val chemId = curriculum.insertSubject(SubjectEntity(name = "Chemistry", category = "Natural Science", colorHex = 0xFF0D9488, iconName = "Biotech"))
        val bioId = curriculum.insertSubject(SubjectEntity(name = "Biology", category = "Natural Science", colorHex = 0xFF16A34A, iconName = "Eco"))
        val englishId = curriculum.insertSubject(SubjectEntity(name = "English", category = "Additional", colorHex = 0xFFD97706, iconName = "MenuBook"))
        val aptitudeId = curriculum.insertSubject(SubjectEntity(name = "Aptitude", category = "Additional", colorHex = 0xFFDC2626, iconName = "Psychology"))

        // Helper to insert Unit + Topics
        suspend fun addUnit(subjectId: Long, gradeLevel: Int, num: Int, title: String, topics: List<String>): Pair<Long, List<Long>> {
            val uid = curriculum.insertUnit(UnitEntity(subjectId = subjectId, gradeId = gradeIds.getValue(gradeLevel), unitNumber = num, title = title))
            val tids = topics.map { curriculum.insertTopic(TopicEntity(unitId = uid, title = it)) }
            return uid to tids
        }

        // Curriculum hierarchy across Grades 9-12 for all 6 subjects
        val (m9u1, m9t) = addUnit(mathId, 9, 1, "The Number System & Sets", listOf("Real Numbers & Surds", "Sets & Venn Diagrams"))
        val (m10u1, m10t) = addUnit(mathId, 10, 2, "Polynomial & Exponential Functions", listOf("Quadratic Equations", "Logarithmic Laws"))
        val (m11u1, m11t) = addUnit(mathId, 11, 3, "Matrices, Vectors & Conics", listOf("Determinants & Inverses", "Conic Sections"))
        val (m12u1, m12t) = addUnit(mathId, 12, 1, "Sequences, Limits & Calculus", listOf("Limits & Continuity", "Derivatives & Optimization", "Definite Integrals"))

        val (p9u1, p9t) = addUnit(physicsId, 9, 1, "Vectors & Kinematics", listOf("Uniformly Accelerated Motion", "Vector Resolution"))
        val (p10u1, p10t) = addUnit(physicsId, 10, 2, "Electrostatics & Circuits", listOf("Ohm's Law & Resistors", "Capacitors"))
        val (p11u1, p11t) = addUnit(physicsId, 11, 3, "Dynamics, Work & Energy", listOf("Newton's Laws & Friction", "Conservation of Momentum"))
        val (p12u1, p12t) = addUnit(physicsId, 12, 2, "Wave Optics & Modern Physics", listOf("Interference & Diffraction", "Photoelectric Effect"))

        val (c9u1, c9t) = addUnit(chemId, 9, 1, "Atomic Structure & Periodic Table", listOf("Electron Configuration", "Periodic Trends"))
        val (c10u1, c10t) = addUnit(chemId, 10, 2, "Chemical Bonding & Stoichiometry", listOf("Mole Concept & Limiting Reactant", "VSEPR & Hybridization"))
        val (c11u1, c11t) = addUnit(chemId, 11, 3, "Chemical Equilibrium & Kinetics", listOf("Le Chatelier's Principle", "Rate Laws"))
        val (c12u1, c12t) = addUnit(chemId, 12, 1, "Acid-Base Equilibria & Electrochemistry", listOf("pH & Buffer Solutions", "Galvanic Cells & Nernst Equation"))

        val (b9u1, b9t) = addUnit(bioId, 9, 1, "Cell Biology & Microscope", listOf("Organelles & Membranes", "Osmosis & Active Transport"))
        val (b10u1, b10t) = addUnit(bioId, 10, 2, "Enzymes & Cellular Respiration", listOf("Enzyme Kinetics", "Glycolysis & Krebs Cycle"))
        val (b11u1, b11t) = addUnit(bioId, 11, 3, "Genetics & Molecular Biology", listOf("Mendelian Inheritance", "DNA Replication & Transcription"))
        val (b12u1, b12t) = addUnit(bioId, 12, 2, "Ecology & Evolution", listOf("Natural Selection", "Biogeochemical Cycles"))

        val (e9u1, e9t) = addUnit(englishId, 9, 1, "Grammar & Sentence Structure", listOf("Tenses & Conditionals", "Modal Auxiliaries"))
        val (e11u1, e11t) = addUnit(englishId, 11, 2, "Vocabulary & Contextual Usage", listOf("Phrasal Verbs & Idioms", "Synonyms & Antonyms"))
        val (e12u1, e12t) = addUnit(englishId, 12, 3, "Reading Comprehension & Writing", listOf("Inference & Tone", "Paragraph Coherence"))

        val (a11u1, a11t) = addUnit(aptitudeId, 11, 1, "Verbal Reasoning", listOf("Analogies & Classifications", "Logical Deduction"))
        val (a12u1, a12t) = addUnit(aptitudeId, 12, 2, "Quantitative Reasoning", listOf("Ratios, Percentages & Sequences", "Data Sufficiency"))

        // 4. Rich EUEE Questions across all 6 subjects
        val questions = listOf(
            // MATHEMATICS
            QuestionEntity(
                uniqueCode = "EUEE-MATH-12-001",
                bankId = builtInBankId,
                subjectId = mathId,
                gradeId = gradeIds.getValue(12),
                unitId = m12u1,
                topicId = m12t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "Evaluate the limit: lim(x → 2) (x² − 4) / (x − 2)",
                correctAnswer = "4",
                acceptedAnswersJson = """["4","4.0"]""",
                optionsJson = """["0","2","4","Undefined"]""",
                hintsJson = """["Factor the numerator using difference of two squares: a² − b² = (a − b)(a + b).","Cancel (x − 2) before substituting x = 2."]""",
                explanation = "Factoring x² − 4 gives (x − 2)(x + 2). Canceling (x − 2) for x ≠ 2 leaves x + 2, which approaches 2 + 2 = 4.",
                whyCorrect = "The 0/0 indeterminate form is removable by algebraic factoring.",
                commonMistakes = "Substituting x = 2 directly and concluding the limit is undefined.",
                conceptExplanation = "A removable discontinuity at x = a does not prevent lim(x → a) f(x) from existing.",
                workedExample = "lim(x → 3) (x² − 9)/(x − 3) = lim(x → 3)(x + 3) = 6.",
                memoryTip = "0/0 means factor, rationalize, or apply L'Hôpital's rule!",
                examTrap = "Selecting 'Undefined' because the denominator is zero at x = 2.",
                referencesText = "Ethiopian Grade 12 Mathematics, Unit 2"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-MATH-12-002",
                bankId = builtInBankId,
                subjectId = mathId,
                gradeId = gradeIds.getValue(12),
                unitId = m12u1,
                topicId = m12t[1],
                difficulty = Difficulty.HARD.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "If f(x) = x³ − 3x² + 2, at what x-value does f(x) attain a local minimum?",
                correctAnswer = "x = 2",
                acceptedAnswersJson = """["x = 2","2"]""",
                optionsJson = """["x = 0","x = 1","x = 2","x = −1"]""",
                hintsJson = """["Find f'(x) and set it to 0 to locate critical points.","Use the second derivative f''(x) = 6x − 6 to classify."]""",
                explanation = "f'(x) = 3x² − 6x = 3x(x − 2) = 0 gives x = 0 and x = 2. Since f''(2) = 6(2) − 6 = 6 > 0, x = 2 is a local minimum.",
                whyCorrect = "f'(2) = 0 and f''(2) > 0 confirms concave-up local minimum.",
                commonMistakes = "Stopping after finding x = 0 and assuming the first critical point is minimum.",
                conceptExplanation = "First derivative test finds stationary points; second derivative test determines concavity.",
                workedExample = "For g(x) = x² − 4x, g'(x) = 2x − 4 = 0 at x = 2, g''(2) = 2 > 0 (min).",
                memoryTip = "f'' > 0 smiles (minimum); f'' < 0 frowns (maximum).",
                examTrap = "x = 0 is a local maximum (f''(0) = −6 < 0), placed first to trap hasty solvers.",
                referencesText = "Ethiopian Grade 12 Mathematics, Unit 3"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-MATH-11-003",
                bankId = builtInBankId,
                subjectId = mathId,
                gradeId = gradeIds.getValue(11),
                unitId = m11u1,
                topicId = m11t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.NUMERICAL.name,
                questionText = "Find the determinant of the 2×2 matrix A = [[5, 3], [2, 4]].",
                correctAnswer = "14",
                acceptedAnswersJson = """["14","14.0"]""",
                optionsJson = """["14","26","7","−14"]""",
                hintsJson = """["For [[a, b], [c, d]], det(A) = ad − bc."]""",
                explanation = "det(A) = (5 × 4) − (3 × 2) = 20 − 6 = 14.",
                whyCorrect = "Product of main diagonal minus product of off-diagonal.",
                commonMistakes = "Adding ad + bc (giving 26) or reversing subtraction (giving −14).",
                conceptExplanation = "A matrix is invertible if and only if its determinant is non-zero.",
                workedExample = "det([[2, 1], [4, 3]]) = 2(3) − 1(4) = 2.",
                memoryTip = "Down-right minus down-left.",
                examTrap = "Forgetting the minus sign between ad and bc.",
                numericalTolerance = 0.001,
                referencesText = "Grade 11 Mathematics, Matrices"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-MATH-10-004",
                bankId = builtInBankId,
                subjectId = mathId,
                gradeId = gradeIds.getValue(10),
                unitId = m10u1,
                topicId = m10t[1],
                difficulty = Difficulty.EASY.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "Solve for x: log₂(x) + log₂(x − 2) = 3",
                correctAnswer = "4",
                acceptedAnswersJson = """["4","x = 4"]""",
                optionsJson = """["4","−2 and 4","2","8"]""",
                hintsJson = """["Combine logs: log₂[x(x − 2)] = 3.","Remember the domain of log₂(y) requires y > 0."]""",
                explanation = "x(x − 2) = 2³ = 8 → x² − 2x − 8 = 0 → (x − 4)(x + 2) = 0. Only x = 4 satisfies x > 2.",
                whyCorrect = "x = −2 is extraneous because log₂(−2) is undefined in ℝ.",
                commonMistakes = "Accepting both −2 and 4 without checking log domain constraints.",
                conceptExplanation = "Logarithmic arguments must always be strictly positive.",
                workedExample = "log₃(x) = 2 ⇒ x = 3² = 9 (> 0).",
                memoryTip = "Always plug roots back into the original log equation!",
                examTrap = "Option '−2 and 4' catches students who skip domain verification.",
                referencesText = "Grade 10 Mathematics, Exponential & Logarithmic Functions"
            ),

            // PHYSICS
            QuestionEntity(
                uniqueCode = "EUEE-PHYS-11-001",
                bankId = builtInBankId,
                subjectId = physicsId,
                gradeId = gradeIds.getValue(11),
                unitId = p11u1,
                topicId = p11t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.NUMERICAL.name,
                questionText = "A 4.0 kg block is pushed along a horizontal surface with μₖ = 0.25 by a horizontal force of 20 N. Take g = 10 m/s². Calculate its acceleration in m/s².",
                correctAnswer = "2.5",
                acceptedAnswersJson = """["2.5","2.5 m/s²","5/2"]""",
                optionsJson = """["2.5 m/s²","5.0 m/s²","7.5 m/s²","1.5 m/s²"]""",
                hintsJson = """["Compute kinetic friction: fₖ = μₖ N = μₖ m g.","Apply Newton's Second Law: F_net = F_applied − fₖ = m a."]""",
                explanation = "N = mg = 4.0 × 10 = 40 N. fₖ = 0.25 × 40 = 10 N. F_net = 20 − 10 = 10 N. a = 10 / 4.0 = 2.5 m/s².",
                whyCorrect = "Net horizontal force is reduced by kinetic friction opposing motion.",
                commonMistakes = "Dividing 20 N directly by 4.0 kg (ignoring friction) to get 5.0 m/s².",
                conceptExplanation = "Newton's Second Law applies to the vector sum of all forces acting on the mass.",
                workedExample = "If F = 30 N, f = 10 N, m = 5 kg → a = (30 − 10)/5 = 4 m/s².",
                memoryTip = "Always draw the Free Body Diagram before computing a = F/m.",
                examTrap = "Using g = 9.8 when the problem states g = 10 m/s².",
                numericalTolerance = 0.05,
                referencesText = "Grade 11 Physics, Dynamics"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-PHYS-12-002",
                bankId = builtInBankId,
                subjectId = physicsId,
                gradeId = gradeIds.getValue(12),
                unitId = p12u1,
                topicId = p12t[1],
                difficulty = Difficulty.HARD.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "In the photoelectric effect, if the frequency of incident light (above threshold f₀) is doubled while intensity remains constant, what happens to the maximum kinetic energy of emitted photoelectrons?",
                correctAnswer = "It more than doubles",
                acceptedAnswersJson = """["It more than doubles"]""",
                optionsJson = """["It stays the same","It doubles exactly","It more than doubles","It halves"]""",
                hintsJson = """["Use Einstein's photoelectric equation: K_max = hf − φ.","Compare 2hf − φ with 2(hf − φ) = 2hf − 2φ."]""",
                explanation = "Initially K₁ = hf − φ. When frequency doubles, K₂ = 2hf − φ = 2(hf − φ) + φ = 2K₁ + φ > 2K₁.",
                whyCorrect = "The work function φ is subtracted only once, so K_max > 2K₁.",
                commonMistakes = "Assuming K_max is directly proportional to frequency without the −φ intercept.",
                conceptExplanation = "K_max = hf − φ is linear with slope h and y-intercept −φ.",
                workedExample = "If hf = 3 eV and φ = 1 eV, K₁ = 2 eV. Doubling f gives hf' = 6 eV, K₂ = 5 eV (> 4 eV).",
                memoryTip = "Test with simple numbers like hf = 3, φ = 1!",
                examTrap = "'It doubles exactly' is the classic EUEE trap.",
                referencesText = "Grade 12 Physics, Modern Physics"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-PHYS-10-003",
                bankId = builtInBankId,
                subjectId = physicsId,
                gradeId = gradeIds.getValue(10),
                unitId = p10u1,
                topicId = p10t[0],
                difficulty = Difficulty.EASY.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "Two resistors of 6 Ω and 3 Ω are connected in parallel across a 12 V battery. What is the total current drawn from the battery?",
                correctAnswer = "6 A",
                acceptedAnswersJson = """["6 A","6"]""",
                optionsJson = """["1.33 A","2 A","6 A","9 A"]""",
                hintsJson = """["Find equivalent resistance: 1/R_eq = 1/6 + 1/3.","Then I = V / R_eq."]""",
                explanation = "R_eq = (6 × 3) / (6 + 3) = 18 / 9 = 2 Ω. Total current I = 12 V / 2 Ω = 6 A.",
                whyCorrect = "Parallel combination lowers equivalent resistance below the smallest resistor.",
                commonMistakes = "Adding resistors in series (6 + 3 = 9 Ω → 1.33 A).",
                conceptExplanation = "In parallel circuits, voltage is shared equally and branch currents sum up.",
                workedExample = "I₁ = 12/6 = 2 A, I₂ = 12/3 = 4 A → I_total = 6 A.",
                memoryTip = "Parallel product over sum: R₁R₂ / (R₁ + R₂).",
                examTrap = "Adding resistances instead of reciprocals.",
                referencesText = "Grade 10 Physics, Electric Circuits"
            ),

            // CHEMISTRY
            QuestionEntity(
                uniqueCode = "EUEE-CHEM-12-001",
                bankId = builtInBankId,
                subjectId = chemId,
                gradeId = gradeIds.getValue(12),
                unitId = c12u1,
                topicId = c12t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.NUMERICAL.name,
                questionText = "Calculate the pH of a 0.005 M aqueous solution of H₂SO₄ assuming complete dissociation of both protons at 25 °C.",
                correctAnswer = "2.0",
                acceptedAnswersJson = """["2","2.0","2.00"]""",
                optionsJson = """["2.0","2.3","1.7","3.0"]""",
                hintsJson = """["H₂SO₄ is diprotic: complete dissociation yields [H⁺] = 2 × 0.005 M.","pH = −log₁₀([H⁺])."]""",
                explanation = "[H⁺] = 2 × 0.005 M = 0.010 M = 10⁻² M. Thus pH = −log₁₀(10⁻²) = 2.0.",
                whyCorrect = "Each mole of H₂SO₄ produces 2 moles of H⁺ under full dissociation.",
                commonMistakes = "Using [H⁺] = 0.005 M directly, giving pH = 2.3.",
                conceptExplanation = "Stoichiometric normality matters for polyprotic strong acids.",
                workedExample = "0.0005 M Ca(OH)₂ → [OH⁻] = 0.001 M → pOH = 3 → pH = 11.",
                memoryTip = "Watch out for diprotic H₂SO₄ and diacidic Ca(OH)₂!",
                examTrap = "2.3 is included specifically for students who forget the factor of 2.",
                numericalTolerance = 0.05,
                referencesText = "Grade 12 Chemistry, Acid-Base Equilibria"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-CHEM-11-002",
                bankId = builtInBankId,
                subjectId = chemId,
                gradeId = gradeIds.getValue(11),
                unitId = c11u1,
                topicId = c11t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "For the exothermic Haber reaction N₂(g) + 3H₂(g) ⇌ 2NH₃(g) (ΔH = −92 kJ/mol), which condition maximizes the equilibrium yield of NH₃?",
                correctAnswer = "High pressure and low temperature",
                acceptedAnswersJson = """["High pressure and low temperature"]""",
                optionsJson = """["High pressure and low temperature","Low pressure and high temperature","High pressure and high temperature","Adding a catalyst alone"]""",
                hintsJson = """["Compare moles of gas: 4 mol reactants → 2 mol products.","Exothermic forward reaction releases heat."]""",
                explanation = "Higher pressure shifts equilibrium toward fewer gas moles (2 < 4). Lower temperature favors the exothermic forward direction. Catalysts speed attainment without shifting equilibrium.",
                whyCorrect = "Le Chatelier's principle favors products under high P and low T.",
                commonMistakes = "Confusing kinetic rate (high T) with equilibrium yield (low T for exothermic).",
                conceptExplanation = "A catalyst lowers activation energy equally for forward and reverse reactions.",
                workedExample = "2SO₂(g) + O₂(g) ⇌ 2SO₃(g), ΔH < 0 also increases yield at high P, low T.",
                memoryTip = "Catalyst = faster equilibrium, NOT more product.",
                examTrap = "Industrial Haber process uses ~450 °C for rate, but equilibrium yield strictly prefers low T.",
                referencesText = "Grade 11 Chemistry, Chemical Equilibrium"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-CHEM-10-003",
                bankId = builtInBankId,
                subjectId = chemId,
                gradeId = gradeIds.getValue(10),
                unitId = c10u1,
                topicId = c10t[0],
                difficulty = Difficulty.EASY.name,
                questionType = QuestionType.SHORT_ANSWER.name,
                questionText = "Write the balanced chemical formula for the product formed when aluminum reacts completely with oxygen gas.",
                correctAnswer = "Al2O3",
                acceptedAnswersJson = """["Al2O3","Al₂O₃"]""",
                optionsJson = """["Al2O3","AlO","Al3O2","AlO2"]""",
                hintsJson = """["Al³⁺ combines with O²⁻ to achieve electrical neutrality."]""",
                explanation = "2 Al³⁺ + 3 O²⁻ → Al₂O₃ (aluminum oxide).",
                whyCorrect = "Crisscrossing valencies 3 and 2 gives Al₂O₃.",
                commonMistakes = "Writing AlO or Al₃O₂.",
                conceptExplanation = "Ionic compound formulas reflect the lowest whole-number ratio balancing total charge.",
                workedExample = "Mg²⁺ and N³⁻ → Mg₃N₂.",
                memoryTip = "4Al + 3O₂ → 2Al₂O₃.",
                examTrap = "Swapping subscripts incorrectly.",
                referencesText = "Grade 10 Chemistry, Chemical Bonding"
            ),

            // BIOLOGY
            QuestionEntity(
                uniqueCode = "EUEE-BIO-11-001",
                bankId = builtInBankId,
                subjectId = bioId,
                gradeId = gradeIds.getValue(11),
                unitId = b11u1,
                topicId = b11t[1],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "During transcription in eukaryotic cells, which enzyme synthesizes mRNA from a DNA template strand?",
                correctAnswer = "RNA polymerase II",
                acceptedAnswersJson = """["RNA polymerase II","RNA polymerase"]""",
                optionsJson = """["DNA polymerase III","RNA polymerase II","DNA helicase","DNA ligase"]""",
                hintsJson = """["Transcription makes RNA, not DNA.","Ligase joins Okazaki fragments during replication."]""",
                explanation = "RNA polymerase II binds to the promoter and synthesizes pre-mRNA in the 5' → 3' direction.",
                whyCorrect = "RNA polymerase II is dedicated to protein-coding mRNA synthesis in eukaryotes.",
                commonMistakes = "Confusing DNA replication enzymes (DNA polymerase III / helicase) with transcription.",
                conceptExplanation = "Central Dogma: DNA → (RNA polymerase) → mRNA → (Ribosome) → Protein.",
                workedExample = "Template 3'-TAC-5' transcribes to mRNA 5'-AUG-3'.",
                memoryTip = "RNA Pol II = Messenger (2 letters mR).",
                examTrap = "DNA polymerase III performs replication, not transcription.",
                referencesText = "Grade 11 Biology, Molecular Genetics"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-BIO-10-002",
                bankId = builtInBankId,
                subjectId = bioId,
                gradeId = gradeIds.getValue(10),
                unitId = b10u1,
                topicId = b10t[1],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "Where in a eukaryotic cell does the Krebs (citric acid) cycle occur?",
                correctAnswer = "Mitochondrial matrix",
                acceptedAnswersJson = """["Mitochondrial matrix"]""",
                optionsJson = """["Cytoplasm (cytosol)","Mitochondrial matrix","Inner mitochondrial membrane","Chloroplast stroma"]""",
                hintsJson = """["Glycolysis happens in the cytosol; oxidative phosphorylation is on the cristae."]""",
                explanation = "Pyruvate enters the mitochondrion and is oxidized in the mitochondrial matrix via the Krebs cycle.",
                whyCorrect = "Soluble Krebs cycle enzymes reside in the mitochondrial matrix.",
                commonMistakes = "Confusing the matrix (Krebs cycle) with cristae/inner membrane (electron transport chain).",
                conceptExplanation = "Compartmentalization separates glycolysis (cytosol), Krebs (matrix), and ETC (cristae).",
                workedExample = "Each glucose yields 2 turns of the Krebs cycle in the matrix.",
                memoryTip = "Glycolysis = Cytosol, Krebs = Matrix, ETC = Cristae.",
                examTrap = "Inner mitochondrial membrane hosts the ETC, not the Krebs cycle.",
                referencesText = "Grade 10 Biology, Cellular Respiration"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-BIO-09-003",
                bankId = builtInBankId,
                subjectId = bioId,
                gradeId = gradeIds.getValue(9),
                unitId = b9u1,
                topicId = b9t[1],
                difficulty = Difficulty.EASY.name,
                questionType = QuestionType.TRUE_FALSE.name,
                questionText = "True or False: Active transport moves solutes across a plasma membrane against their concentration gradient without requiring cellular ATP.",
                correctAnswer = "False",
                acceptedAnswersJson = """["False","F"]""",
                optionsJson = """["True","False"]""",
                hintsJson = """["Moving uphill against a gradient requires energy input."]""",
                explanation = "False. Active transport requires metabolic energy (typically ATP hydrolysis, e.g., Na⁺/K⁺ pump) to move substances from low to high concentration.",
                whyCorrect = "Passive diffusion/osmosis require no ATP; active transport always requires energy.",
                commonMistakes = "Confusing facilitated diffusion (passive) with active transport.",
                conceptExplanation = "Active transport maintains electrochemical gradients across membranes.",
                workedExample = "Root hair cells absorb mineral ions via active transport.",
                memoryTip = "Active = ATP required.",
                examTrap = "Watch for the qualifier 'without requiring cellular ATP'.",
                referencesText = "Grade 9 Biology, Cell Transport"
            ),

            // ENGLISH
            QuestionEntity(
                uniqueCode = "EUEE-ENG-12-001",
                bankId = builtInBankId,
                subjectId = englishId,
                gradeId = gradeIds.getValue(12),
                unitId = e12u1,
                topicId = e12t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "Choose the grammatically correct completion: 'Had the students revised the past papers thoroughly, they _____ the entrance exam with greater confidence.'",
                correctAnswer = "would have approached",
                acceptedAnswersJson = """["would have approached"]""",
                optionsJson = """["will approach","would approach","would have approached","had approached"]""",
                hintsJson = """["Identify the inverted third conditional: 'Had + subject + V3' = 'If + subject + had + V3'."]""",
                explanation = "'Had the students revised...' is an inverted Type 3 conditional referring to an unreal past condition, requiring 'would have + past participle' in the main clause.",
                whyCorrect = "Third conditional structure pairs past perfect condition with 'would have + V3'.",
                commonMistakes = "Using 'would approach' (Type 2 conditional) for a past counterfactual.",
                conceptExplanation = "Inverted conditionals omit 'if' and front 'Had', 'Were', or 'Should'.",
                workedExample = "Had I known earlier, I would have called you.",
                memoryTip = "Had + V3 → would have + V3.",
                examTrap = "'would approach' looks natural at first glance but mismatches past time.",
                referencesText = "Grade 12 English, Conditional Clauses"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-ENG-11-002",
                bankId = builtInBankId,
                subjectId = englishId,
                gradeId = gradeIds.getValue(11),
                unitId = e11u1,
                topicId = e11t[0],
                difficulty = Difficulty.EASY.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "Select the meaning closest to the underlined phrasal verb: 'Because of the heavy rain, the committee decided to call off the outdoor science fair.'",
                correctAnswer = "cancel",
                acceptedAnswersJson = """["cancel"]""",
                optionsJson = """["postpone","cancel","relocate","announce"]""",
                hintsJson = """["Distinguish 'call off' from 'put off'."]""",
                explanation = "'Call off' means to cancel an event entirely; 'put off' means to postpone.",
                whyCorrect = "Standard idiomatic meaning of 'call off'.",
                commonMistakes = "Confusing 'call off' (cancel) with 'put off' (postpone).",
                conceptExplanation = "Phrasal verb particles dramatically change verb meaning.",
                workedExample = "The match was put off until Sunday (postponed) vs. called off (canceled).",
                memoryTip = "Call OFF = switch OFF completely (cancel).",
                examTrap = "'Postpone' is always placed alongside 'cancel' in EUEE English papers.",
                referencesText = "Grade 11 English, Phrasal Verbs"
            ),

            // APTITUDE
            QuestionEntity(
                uniqueCode = "EUEE-APT-12-001",
                bankId = builtInBankId,
                subjectId = aptitudeId,
                gradeId = gradeIds.getValue(12),
                unitId = a12u1,
                topicId = a12t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.NUMERICAL.name,
                questionText = "Find the next term in the number sequence: 3, 7, 15, 31, 63, _____",
                correctAnswer = "127",
                acceptedAnswersJson = """["127"]""",
                optionsJson = """["95","125","127","129"]""",
                hintsJson = """["Examine differences: +4, +8, +16, +32... or the rule 2n + 1."]""",
                explanation = "Each term is 2×(previous) + 1: 63 × 2 + 1 = 127 (also differences double: +64 → 63 + 64 = 127).",
                whyCorrect = "Both the recurrence aₙ = 2aₙ₋₁ + 1 and doubling differences yield 127.",
                commonMistakes = "Adding 32 again instead of doubling to 64.",
                conceptExplanation = "Notice powers of 2 minus 1: 2²−1, 2³−1, 2⁴−1, 2⁵−1, 2⁶−1, 2⁷−1 = 127.",
                workedExample = "2⁷ − 1 = 128 − 1 = 127.",
                memoryTip = "Check both differences and powers of 2!",
                examTrap = "125 and 129 sit right beside 127 to catch arithmetic slips.",
                numericalTolerance = 0.001,
                referencesText = "EUEE Scholastic Aptitude, Quantitative Reasoning"
            ),
            QuestionEntity(
                uniqueCode = "EUEE-APT-11-002",
                bankId = builtInBankId,
                subjectId = aptitudeId,
                gradeId = gradeIds.getValue(11),
                unitId = a11u1,
                topicId = a11t[0],
                difficulty = Difficulty.MEDIUM.name,
                questionType = QuestionType.MULTIPLE_CHOICE.name,
                questionText = "SCALPEL : SURGEON :: _____ : _____",
                correctAnswer = "CHISEL : SCULPTOR",
                acceptedAnswersJson = """["CHISEL : SCULPTOR"]""",
                optionsJson = """["CHISEL : SCULPTOR","PATIENT : HOSPITAL","WOOD : CARPENTER","POEM : AUTHOR"]""",
                hintsJson = """["Identify the bridge: [Precision cutting/shaping tool] : [Profession that uses it]."]""",
                explanation = "A scalpel is the primary precision hand tool used by a surgeon, just as a chisel is the precision tool used by a sculptor.",
                whyCorrect = "Preserves exact Tool : Practitioner relationship and word order.",
                commonMistakes = "Choosing 'WOOD : CARPENTER' (material : practitioner) or 'POEM : AUTHOR' (product : creator).",
                conceptExplanation = "Always verify both relationship type and directionality in analogies.",
                workedExample = "BRUSH : PAINTER :: TELESCOPE : ASTRONOMER.",
                memoryTip = "Build a crisp sentence bridge: 'A [X] is a tool wielded by a [Y].'",
                examTrap = "Distractors match the domain (carpenter, author) while reversing or shifting the bridge.",
                referencesText = "EUEE Scholastic Aptitude, Verbal Analogies"
            )
        )

        db.questionDao().insertQuestions(questions)

        // 5. Starter Notebook Notes & Flashcards
        val note1Id = db.notebookDao().upsertNote(
            NoteEntity(
                subjectId = chemId,
                topicId = c12t[0],
                title = "Strong Polyprotic Acids & pH Shortcuts",
                content = "Remember: H₂SO₄ yields 2 H⁺ per formula unit in dilute complete-dissociation problems. Always compute [H⁺] = n × Molarity before taking −log₁₀([H⁺]).",
                isPinned = true
            )
        )
        db.notebookDao().upsertNote(
            NoteEntity(
                subjectId = mathId,
                topicId = m12t[1],
                title = "Calculus Local Extrema Checklist",
                content = "1. Compute f'(x) and solve f'(x) = 0.\n2. Check domain endpoints if interval is closed.\n3. Evaluate f''(x): positive = local min, negative = local max.",
                isPinned = false
            )
        )

        db.notebookDao().upsertFlashcard(
            FlashcardEntity(
                subjectId = chemId,
                topicId = c12t[0],
                front = "What is the relationship between [H⁺] and molarity for completely dissociated H₂SO₄?",
                back = "[H⁺] = 2 × M (diprotic acid). Example: 0.005 M H₂SO₄ → 0.01 M H⁺ → pH = 2.0.",
                hint = "Count ionizable protons.",
                sourceNoteId = note1Id
            )
        )
        db.notebookDao().upsertFlashcard(
            FlashcardEntity(
                subjectId = physicsId,
                topicId = p12t[1],
                front = "Einstein's Photoelectric Equation",
                back = "K_max = h·f − φ (where φ = h·f₀ is the work function of the metal).",
                hint = "Energy of photon minus binding threshold."
            )
        )
        db.notebookDao().upsertFlashcard(
            FlashcardEntity(
                subjectId = bioId,
                topicId = b10t[1],
                front = "Where do Glycolysis, Krebs Cycle, and ETC take place?",
                back = "Glycolysis → Cytosol\nKrebs Cycle → Mitochondrial Matrix\nETC → Inner Mitochondrial Membrane (Cristae)",
                hint = "Three compartments from outside to inside."
            )
        )

        // 6. Starter Today's Study Tasks
        val today = LocalDate.now().toEpochDay()
        db.plannerAndAlarmDao().upsertTask(
            StudyTaskEntity(
                title = "Mathematics: Limits & Derivatives Drill",
                notes = "Complete 15 Smart Study questions and review calculus traps",
                subjectId = mathId,
                unitId = m12u1,
                topicId = m12t[0],
                scheduledDateEpochDay = today,
                startTimeMinutes = 16 * 60, // 4:00 PM
                durationMinutes = 45,
                priority = TaskPriority.HIGH.name
            )
        )
        db.plannerAndAlarmDao().upsertTask(
            StudyTaskEntity(
                title = "Chemistry: Acid-Base pH & Equilibrium",
                notes = "Review Henderson-Hasselbalch and Le Chatelier notes",
                subjectId = chemId,
                unitId = c12u1,
                topicId = c12t[0],
                scheduledDateEpochDay = today,
                startTimeMinutes = 18 * 60 + 30, // 6:30 PM
                durationMinutes = 40,
                priority = TaskPriority.MEDIUM.name
            )
        )

        // 7. Starter disabled Alarm template (user enables when ready)
        db.plannerAndAlarmDao().upsertAlarm(
            AlarmEntity(
                label = "Morning EUEE Revision",
                hour = 6,
                minute = 30,
                daysOfWeekMask = 0b0111110, // Mon-Fri
                isRepeating = true,
                isEnabled = false,
                category = AlarmCategory.STUDY_REMINDER.name,
                subjectId = mathId,
                vibrate = true,
                snoozeMinutes = 10
            )
        )
    }
}
